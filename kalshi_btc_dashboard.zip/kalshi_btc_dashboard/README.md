# Kalshi Bitcoin 15-minute market monitor

A read-only Streamlit prototype for viewing public Kalshi 15-minute BTC markets, calculating gross contract payoffs, and logging hypothetical trades.

## Deploy to Streamlit Community Cloud
1. Create a **public** GitHub repository, e.g. `kalshi-bitcoin-dashboard`.
2. Upload `app.py` and `requirements.txt` to the repository root. Do not upload passwords, private API keys, or credentials.
3. Sign in to Streamlit Community Cloud with GitHub, choose **Create app**, select your repository, branch `main`, and entrypoint `app.py`.
4. Deploy and open the resulting URL.

## Important limitations
- No independent probability model, backtest, BUY/SELL recommendations, automated trades, or real-money order execution.
- Market data is fetched from Kalshi's public API and cached for eight seconds; press **Refresh now** to update. It is **not** a continuously running live feed.
- Market series names and API fields can change. If no market is found, check Kalshi's current API documentation.
- Paper-trade notebook is held in Streamlit session state, not a database. Export CSV to retain entries.
- Calculator omits fees, spread, slippage, and early-exit execution.
- Public Streamlit apps may be visible to others; do not enter sensitive information.
