import time
from datetime import datetime, timezone
from decimal import Decimal
import requests
import streamlit as st

st.set_page_config(page_title='Bitcoin 15-Minute Market Monitor', page_icon='₿', layout='wide')
st.title('₿ Bitcoin 15-Minute Market Monitor')
st.caption('Read-only Kalshi market monitor • Educational prototype • No orders placed')

BASE = 'https://api.elections.kalshi.com/trade-api/v2'
SERIES = 'KXBTC15M'

@st.cache_data(ttl=8, show_spinner=False)
def get_markets():
    s = requests.Session()
    s.headers.update({'User-Agent':'btc15m-monitor/0.1'})
    errors = []
    for params in ({'series_ticker':SERIES, 'limit':100, 'status':'open'}, {'limit':200, 'status':'open'}):
        try:
            r = s.get(f'{BASE}/markets', params=params, timeout=12)
            r.raise_for_status()
            items = r.json().get('markets', [])
            if 'series_ticker' not in params:
                items = [m for m in items if m.get('ticker','').startswith(SERIES) or ('bitcoin' in (m.get('title','')+' '+m.get('subtitle','')).lower() and '15' in (m.get('title','')+' '+m.get('subtitle','')).lower())]
            if items:
                return items, None
            errors.append('No matching markets in response')
        except (requests.RequestException, ValueError) as exc:
            errors.append(str(exc))
    return [], '; '.join(errors)

def price(m, key):
    val = m.get(key + '_dollars')
    if val not in (None, ''):
        try: return float(Decimal(str(val)))
        except Exception: pass
    val = m.get(key)
    return float(val)/100 if val is not None else None

def fmt_price(p): return f'{p:.0%}' if p is not None else '—'

def parse_dt(s):
    if not s: return None
    try: return datetime.fromisoformat(s.replace('Z','+00:00'))
    except ValueError: return None

with st.sidebar:
    st.header('Controls')
    stake = st.number_input('Illustrative stake ($)', min_value=1, max_value=10000, value=50, step=10)
    st.write('Prices refresh when you reload or click Refresh. This prototype does not stream data.')
    if st.button('↻ Refresh now', use_container_width=True):
        get_markets.clear()
        st.rerun()
    st.info('No login, API keys, or trading permissions are required.')

markets, err = get_markets()
if not markets:
    st.warning('No open 15-minute Bitcoin markets were returned. The series identifier or API availability may have changed.')
    if err: st.caption(f'Diagnostic: {err}')
    st.markdown('You can still use the calculator below. Check the official Kalshi market page for the active contract.')
else:
    now = datetime.now(timezone.utc)
    markets.sort(key=lambda m: parse_dt(m.get('close_time')) or datetime.max.replace(tzinfo=timezone.utc))
    choices = {f"{m.get('ticker','?')} — closes {m.get('close_time','unknown')}":m for m in markets[:30]}
    selection = st.selectbox('Market', list(choices))
    m = choices[selection]
    end = parse_dt(m.get('close_time'))
    remaining = max(0, int((end-now).total_seconds())) if end else None
    yes, no = price(m,'yes_ask'), price(m,'no_ask')
    yes_bid, no_bid = price(m,'yes_bid'), price(m,'no_bid')
    st.subheader(m.get('title') or m.get('ticker'))
    a,b,c,d = st.columns(4)
    a.metric('YES ask', fmt_price(yes))
    b.metric('NO ask', fmt_price(no))
    c.metric('Time to close', f'{remaining//60}:{remaining%60:02d}' if remaining is not None else '—')
    d.metric('Volume', f"{m.get('volume', 0):,}" if isinstance(m.get('volume'),int) else str(m.get('volume','—')))
    st.caption(f"Ticker: {m.get('ticker','—')} | YES bid: {fmt_price(yes_bid)} | NO bid: {fmt_price(no_bid)}")
    st.warning('WAIT — No validated probability model is connected. Current prices are market quotes, not independent predictions.')
    st.markdown('**Market description:** '+str(m.get('rules_primary') or m.get('subtitle') or 'Read the official contract rules before trading.'))

st.divider()
st.subheader('Position payoff calculator')
side = st.radio('Side', ['YES','NO'], horizontal=True)
entry_cents = st.slider('Hypothetical purchase price (¢)', 1, 99, 60)
contracts = int(stake // (entry_cents/100))
cost = contracts * entry_cents/100
win_profit = contracts - cost
lose_profit = -cost
break_even = entry_cents/100
x,y,z = st.columns(3)
x.metric('Contracts purchasable', f'{contracts:,}')
y.metric('Gross profit if correct', f'${win_profit:,.2f}')
z.metric('Gross loss if incorrect', f'${-lose_profit:,.2f}')
st.caption(f'Gross break-even probability: {break_even:.1%}. Actual break-even is higher after fees and slippage. The calculator excludes fees, partial fills and early exits.')

st.divider()
st.subheader('Paper trade notebook (this browser session only)')
if 'paper' not in st.session_state: st.session_state.paper = []
if st.button('Record hypothetical entry'):
    st.session_state.paper.append({'UTC recorded':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S'), 'Side':side,'Price (¢)':entry_cents,'Contracts':contracts,'Cost ($)':round(cost,2),'Status':'OPEN — unverified'})
if st.session_state.paper:
    st.dataframe(st.session_state.paper, use_container_width=True)
    st.download_button('Export notebook CSV', __import__('pandas').DataFrame(st.session_state.paper).to_csv(index=False), file_name='paper_trades.csv', mime='text/csv')
st.caption('Entries are not executed or automatically settled. Session records can disappear on restart; export them if needed.')
st.divider()
st.caption('Data source: public Kalshi API. This is an experimental informational tool, not financial advice. The contract settlement index may differ from a spot BTC chart.')
